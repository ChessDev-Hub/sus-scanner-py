# SusScanner API

Backend service for SusScanner.

## 🚀 Deploy on Render (default)
1. Push this repo to GitHub (e.g., ChessDev-Hub/sus-scanner-api).
2. On [Render](https://render.com), create a **Blueprint** service.
3. Connect the repo and let Render read `render.yaml`.
4. After deploy, your API will be live at `https://<your-app>.onrender.com`.

Endpoints:
- `/health` → check API status
- `/analyze/{username}` → run analysis for a Chess.com user

CORS is preconfigured for:
- https://chessdev-hub.github.io
- https://chessdev-hub.github.io/sus-scanner

## ☁️ Alternative: Deploy on Cloud Run
```bash
gcloud builds submit --tag gcr.io/PROJECT_ID/sus-scanner-api
gcloud run deploy sus-scanner-api --image gcr.io/PROJECT_ID/sus-scanner-api --platform managed
```
