# api/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from scanner import analyze_player

app = FastAPI()

origins = [
    "https://chessdev-hub.github.io",
    "https://chessdev-hub.github.io/sus-scanner"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/analyze/{username}")
def analyze(username: str):
    return analyze_player(username)
