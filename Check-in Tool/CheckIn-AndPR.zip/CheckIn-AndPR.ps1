<# 
   CheckIn-AndPR.ps1
   Stages changes, commits, pushes a branch to GitHub (ChessDev-Hub org),
   opens a PR into main, and applies labels/reviewers.

   Requires: git, GitHub CLI (gh) authenticated to your GitHub account
#>

[CmdletBinding()]
param(
  [string]$Org = "ChessDev-Hub",
  [string]$Repo = "sus-scanner",
  [string]$BaseBranch = "main",

  # If empty, a feature branch name will be generated.
  [string]$FeatureBranch = "",

  # Commit & PR metadata
  [Parameter(Mandatory=$true)]
  [string]$CommitMessage,

  [string]$PrTitle = "",
  [string]$PrBody = "Automated PR via CheckIn-AndPR.ps1",
  [string[]]$Labels = @("automation", "needs-review"),
  [string[]]$Reviewers = @(),            # e.g. @("ChessDev-Hub/dev1","ChessDev-Hub/dev2")
  [switch]$Draft,                         # opens PR as draft
  [switch]$SkipIfNoChanges,               # silently exit when nothing to commit
  [switch]$DirectPush                     # tries to push to BaseBranch directly (if branch not protected)
)

function Fail($msg) { Write-Error $msg; exit 1 }

# --- Pre-flight checks ---
git --version *> $null 2>&1; if ($LASTEXITCODE -ne 0) { Fail "git not found. Install Git first." }
gh --version  *> $null 2>&1; if ($LASTEXITCODE -ne 0) { Fail "GitHub CLI (gh) not found. Install and run 'gh auth login'." }

# Ensure we’re inside a git repo
if (-not (Test-Path ".git")) {
  Write-Host "Initializing git repo..."
  git init || Fail "git init failed."
}

# Ensure remote "origin" points to the ChessDev-Hub repo
$expectedRemote = "https://github.com/$Org/$Repo.git"
$remoteUrl = ""
try { $remoteUrl = (git remote get-url origin 2>$null) } catch {}
if (-not $remoteUrl) {
  Write-Host "Adding remote origin $expectedRemote"
  git remote add origin $expectedRemote || Fail "Failed to add remote origin."
} elseif ($remoteUrl -ne $expectedRemote) {
  Write-Host "Updating remote origin to $expectedRemote"
  git remote set-url origin $expectedRemote || Fail "Failed to update remote origin."
}

# Fetch and sync base
git fetch origin || Fail "git fetch origin failed."
git checkout -B $BaseBranch "origin/$BaseBranch" 2>$null || git checkout -B $BaseBranch || Fail "Checkout $BaseBranch failed."
git pull --ff-only origin $BaseBranch || Write-Warning "Couldn't fast-forward $BaseBranch (continuing)."

# Decide path: direct push vs PR
if ($DirectPush) {
  Write-Host "`n[Mode] Direct push to $BaseBranch"
  git add -A
  if (-not (git diff --cached --quiet)) {
    git commit -m $CommitMessage || Fail "Commit failed."
    git push origin $BaseBranch || Fail "Push to $BaseBranch failed (branch may be protected)."
    Write-Host "✅ Pushed directly to $Org/$Repo:$BaseBranch"
  } else {
    if ($SkipIfNoChanges) { Write-Host "No staged changes. Exiting."; exit 0 }
    Fail "No changes to commit."
  }
  exit 0
}

# PR mode
if (-not $FeatureBranch) {
  $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
  # Slug the first few words of the commit message
  $slug = ($CommitMessage -replace '[^a-zA-Z0-9\- ]','' -replace '\s+','-').ToLower()
  if ($slug.Length -gt 40) { $slug = $slug.Substring(0,40) }
  $FeatureBranch = "feat/$stamp-$slug"
}

Write-Host "`n[Mode] PR into $BaseBranch via branch $FeatureBranch"

git checkout -B $FeatureBranch || Fail "Create/switch to feature branch failed."
git merge --ff-only $BaseBranch 2>$null | Out-Null

git add -A
if (git diff --cached --quiet) {
  if ($SkipIfNoChanges) { Write-Host "No changes to commit. Exiting."; exit 0 }
  Fail "No changes to commit."
}
git commit -m $CommitMessage || Fail "Commit failed."

git push -u origin $FeatureBranch || Fail "Push branch failed."

if (-not $PrTitle) { $PrTitle = $CommitMessage }

# Build gh pr create args
$draftFlag = $Draft.IsPresent ? "--draft" : ""
$prCreateCmd = @(
  "pr","create",
  "--repo","$Org/$Repo",
  "--base",$BaseBranch,
  "--head",$FeatureBranch,
  "--title",$PrTitle,
  "--body",$PrBody
)
if ($Draft) { $prCreateCmd += "--draft" }

# Create PR
$prUrl = ""
try {
  $prUrl = (gh @prCreateCmd).Trim()
} catch {
  # If PR already exists, get the URL
  $prUrl = (gh pr view --repo "$Org/$Repo" --head "$FeatureBranch" --json url -q ".url" 2>$null)
  if (-not $prUrl) { Fail "PR create failed and no existing PR found." }
}
Write-Host "`nPR: $prUrl"

# Apply labels
if ($Labels -and $Labels.Count -gt 0) {
  try {
    gh issue edit ($prUrl.Split('/')[-1]) --repo "$Org/$Repo" --add-label ($Labels -join ",") | Out-Null
    Write-Host "Labels added: $($Labels -join ', ')"
  } catch {
    Write-Warning "Could not add labels."
  }
}

# Request reviewers
if ($Reviewers -and $Reviewers.Count -gt 0) {
  try {
    gh pr edit $prUrl --repo "$Org/$Repo" --add-reviewer ($Reviewers -join ",") | Out-Null
    Write-Host "Reviewers requested: $($Reviewers -join ', ')"
  } catch {
    Write-Warning "Could not request reviewers."
  }
}

Write-Host "`n✅ Done! Branch pushed and PR opened:"
Write-Host $prUrl
