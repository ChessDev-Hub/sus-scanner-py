# CheckIn-AndPR.ps1

## How to Use

From your repo root (where `.git` is), run:

```powershell
# Example: normal PR flow into main with labels + body
.\CheckIn-AndPR.ps1 `
  -Org "ChessDev-Hub" `
  -Repo "sus-scanner" `
  -BaseBranch "main" `
  -CommitMessage "docs: add anonymized forum-ready table + reasons" `
  -PrTitle "Docs: anonymized forum export" `
  -PrBody "Adds REMOVED-username export for forum sharing." `
  -Labels "docs","needs-review" `
  -Reviewers "ChessDev-Hub/your-teammate" 
```

**Tip:** If your `main` is **not** protected and you just want to push straight to it:

```powershell
.\CheckIn-AndPR.ps1 `
  -CommitMessage "quick hotfix: table header alignment" `
  -DirectPush `
  -SkipIfNoChanges
```

Make sure you have [GitHub CLI](https://cli.github.com/) installed and authenticated via:

```powershell
gh auth login
```
